# Changelog

## v4.0
- Bilingual systray (IT/EN) with auto language detection.
- Tray icon color states: White (normal), Green (mounted), Red (error).
- Agent (“service”) controllable from tray (start/stop/restart/status).
- Single-file self-extracting PowerShell installer (install/uninstall).
- Documentation bundle (README, MANUAL, FAQ, HOWTO).
